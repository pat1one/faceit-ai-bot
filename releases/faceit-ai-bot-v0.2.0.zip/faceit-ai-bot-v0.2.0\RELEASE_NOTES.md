# Faceit AI Bot v0.2.0

## 📦 Что включено в релиз

### 🌐 Browser Extension
- `faceit-ai-bot-extension-v0.2.0.zip` - готовое расширение для браузера
- Установка: распакуйте и загрузите в Chrome/Edge через chrome://extensions

### 🐳 Docker Deployment
- Все необходимые Docker файлы для деплоя
- Docker Compose конфигурация
- Скрипты автоматического деплоя

### 📚 Документация
- README.md - основная документация
- Примеры конфигурации (.env.example)

## 🚀 Быстрый старт

### Установка расширения для браузера
1. Распакуйте `faceit-ai-bot-extension-v0.2.0.zip`
2. Откройте chrome://extensions
3. Включите "Режим разработчика"
4. Нажмите "Загрузить распакованное расширение"
5. Выберите папку с расширением

### Деплой через Docker
```bash
cd docker
cp .env.example .env
# Отредактируйте .env файл
docker-compose up -d
```

### Деплой с помощью скриптов
```bash
cd scripts
chmod +x *.sh
./deploy.sh
```

## 📊 Доступные сервисы после деплоя
- 🌐 Frontend: http://localhost:3000
- 🔧 Backend API: http://localhost:8000
- 📚 API Docs: http://localhost:8000/docs
- 💾 PostgreSQL: localhost:5432

## 🔧 Технологии
- Frontend: Next.js 15, React 19, TypeScript
- Backend: FastAPI, Python 3.9+
- Database: PostgreSQL 16
- Browser Extension: Webpack, Babel
- Deployment: Docker, Docker Compose

## 📝 Changelog
- Обновление до версии 0.2.0
- Улучшения производительности
- Исправления ошибок

---
Дата релиза: 2025-11-08
